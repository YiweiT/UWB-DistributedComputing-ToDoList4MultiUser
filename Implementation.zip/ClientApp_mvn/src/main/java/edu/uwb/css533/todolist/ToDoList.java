package edu.uwb.css533.todolist;

public class ToDoList {
    private String listid;
    private String listname;

    public String getListid() {
        return this.listid;
    }

    public String getListname() {
        return this.listname;
    }
}