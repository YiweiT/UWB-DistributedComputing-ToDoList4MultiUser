package edu.uwb.css533.todolist;

public class Task {
    private String taskname;
    private String taskid;
    private String content;
    private String status;

    public String getTaskname() {
        return this.taskname;
    }

    public String getTaskid() {
        return this.taskid;
    }

    public String getContent() {
        return this.content;
    }

    public String getStatus() {
        return this.status;
    }
}

